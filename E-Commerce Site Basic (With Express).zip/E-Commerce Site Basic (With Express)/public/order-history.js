fetch('/api/orders')
    .then(response => response.json())
    .then(data => {
        console.log('Fetched order data:', data); // Log data for inspection
        const tableBody = document.querySelector('#orderTable tbody');
        tableBody.innerHTML = ''; // Clear any existing content

        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4">No orders found.</td></tr>';
            return;
        }

        data.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.id || 'N/A'}</td>
                <td>${order.product_id || 'N/A'}</td>
                <td>${order.quantity || 'N/A'}</td>
                <td>${order.order_date ? new Date(order.order_date).toLocaleString() : 'N/A'}</td>
            `;
            tableBody.appendChild(row);
        });
    })
    .catch(error => console.error('Error fetching order history:', error));

