// Fetch products from the backend and display them
async function displayProducts() {
    try {
        const response = await fetch('/api/products');
        if (!response.ok) throw new Error('Failed to fetch products');

        const products = await response.json();
        console.log('Fetched products:', products); // Debugging log

        const productList = document.querySelector('.product-list');
        productList.innerHTML = ''; // Clear existing products

        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';
            productDiv.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price}</p>
                <button onclick="addToCart(${product.id})">Add to Cart</button>
            `;
            productList.appendChild(productDiv);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// Handle adding to cart
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(productId) {
    fetch(`/api/products/${productId}`)
        .then(response => response.json())
        .then(product => {
            const existingProduct = cart.find(p => p.id === productId);
            if (existingProduct) {
                existingProduct.quantity += 1;
            } else {
                cart.push({ ...product, quantity: 1 });
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            alert(`${product.name} has been added to the cart.`);
        });
}

document.addEventListener('DOMContentLoaded', displayProducts);
