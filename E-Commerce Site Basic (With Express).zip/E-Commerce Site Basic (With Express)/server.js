const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bodyParser = require('body-parser'); // Add body-parser to handle JSON data
const app = express();
const port = 3001;

// MySQL connection setup
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Add this line with your actual MySQL password
    database: 'ecommerce_store'
});

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL Connected...');
});

// Middleware to serve static files from 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json()); // Use body-parser middleware to parse JSON data

// API endpoint to get all products
app.get('/api/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// API endpoint to get a single product by ID
app.get('/api/products/:id', (req, res) => {
    db.query('SELECT * FROM products WHERE id = ?', [req.params.id], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            res.json(result[0]);
        } else {
            res.status(404).send('Product not found');
        }
    });
});

// API endpoint to process orders
app.post('/api/orders', (req, res) => {
    const cart = req.body.cart;
    if (!cart || cart.length === 0) {
        return res.status(400).send('Cart is empty');
    }

    const orderInsertQuery = 'INSERT INTO orders (product_id, quantity, order_date) VALUES ?';
    const orderValues = cart.map(item => [item.id, item.quantity, new Date()]);

    db.query(orderInsertQuery, [orderValues], (err, result) => {
        if (err) {
            console.error('Database insertion error:', err);
            return res.status(500).send('Error processing order');
        }
        console.log('Order inserted:', result);
        res.status(200).send('Order received');
    });
});

// API endpoint to get order history
app.get('/api/orders', (req, res) => {
    db.query('SELECT * FROM orders', (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).send('Database query error');
        }
        console.log('Order history data:', results); // Log data for inspection
        res.json(results);
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/cart', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cart.html'));
});

app.get('/order-history', (req, res) => {  // Renamed route to avoid conflict
    res.sendFile(path.join(__dirname, 'public', 'order-history.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
